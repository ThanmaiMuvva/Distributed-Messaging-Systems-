#!/bin/bash
go build -o my-binary
../maelstrom/maelstrom test -w unique-ids --bin ./my-binary --time-limit 30 --rate 1000 --node-count 3 --availability total --nemesis partition