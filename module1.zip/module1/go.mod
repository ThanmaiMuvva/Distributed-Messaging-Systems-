module module1

go 1.25.5

require github.com/jepsen-io/maelstrom/demo/go v0.0.0-20251128144731-cb7f07239012
