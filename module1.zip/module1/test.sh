#!/bin/bash
go build -o my-binary
../maelstrom/maelstrom test -w echo --bin ./my-binary --node-count 1 --time-limit 10